package com.examly.springapp.dao;


import com.examly.springapp.model.Hotel;


public interface HotelDAO {
    void addHotelDetailsInList(Hotel hotel);
    void viewAllHotels();
    void createHotel(Hotel hotel);
    void updateHotel(Hotel hotel);
    Hotel getHotelById(int id);
    void deleteHotel(int id);
}