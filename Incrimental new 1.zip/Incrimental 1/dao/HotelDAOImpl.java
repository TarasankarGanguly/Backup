package com.examly.springapp.dao;


import com.examly.springapp.model.Hotel;
import com.examly.springapp.exception.LowRankingException;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class HotelDAOImpl implements HotelDAO {
    private List<Hotel> hotelList = new ArrayList<>();


    @Override
    public void addHotelDetailsInList(Hotel hotel) {
        hotelList.add(hotel);
    }


    @Override
    public void viewAllHotels(){
        String query = "SELECT * FROM hotels";
        try (Connection connection = JDBCUtils.getConnection();
        Statement statement = connection.createStatement())
        {
            
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()) {
                //Hotel hotel = new Hotel();
                int hotelId=resultSet.getInt("hotelId");
                String hotelName= resultSet.getString("hotelName");
                String hotelLocation= resultSet.getString("hotelLocation");
                Float hotelRanking = resultSet.getFloat("hotelRanking");
                boolean gymAvailable = resultSet.getBoolean("gymAvailable");
                boolean poolAvailable = resultSet.getBoolean("poolAvailable");
                boolean spaAvailable = resultSet.getBoolean("spaAvailable");
                Hotel hotel = new Hotel(hotelId, hotelName, hotelLocation, hotelRanking,gymAvailable ,poolAvailable, spaAvailable);
                addHotelDetailsInList(hotel);
            }
                for (Hotel hotel : hotelList) {
                    System.out.println(hotel);
                }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            hotelList.clear();
        }
    }


    @Override
    public void createHotel(Hotel hotel) {
        try {
            String query = "INSERT INTO hotels (hotelId, hotelName, hotelLocation, hotelRanking, gymAvailable, poolAvailable, spaAvailable) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (Connection connection = JDBCUtils.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, hotel.getHotelId());
                preparedStatement.setString(2, hotel.getHotelName());
                preparedStatement.setString(3, hotel.getHotelLocation());
                preparedStatement.setFloat(4, hotel.getHotelRanking());
                preparedStatement.setBoolean(5, hotel.isGymAvailable());
                preparedStatement.setBoolean(6, hotel.isPoolAvailable());
                preparedStatement.setBoolean(7, hotel.isSpaAvailable());
                int row = preparedStatement.executeUpdate();
                if(row>0){
                    System.out.println("Inserted successfully.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error creating hotel: " + e.getMessage());
        }
    }


    @Override
    public void updateHotel(Hotel hotel) {
        try {
            String query = "UPDATE hotels SET hotelName = ?, hotelLocation = ?, hotelRanking = ?, gymAvailable = ?, poolAvailable = ?, spaAvailable = ? WHERE hotelId = ?";
            try (Connection connection = JDBCUtils.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, hotel.getHotelName());
                preparedStatement.setString(2, hotel.getHotelLocation());
                preparedStatement.setFloat(3, hotel.getHotelRanking());
                preparedStatement.setBoolean(4, hotel.isGymAvailable());
                preparedStatement.setBoolean(5, hotel.isPoolAvailable());
                preparedStatement.setBoolean(6, hotel.isSpaAvailable());
                preparedStatement.setInt(7, hotel.getHotelId());
                int row = preparedStatement.executeUpdate();
                if(row>0){
                    System.out.println("Updated successfully.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error updating hotel: " + e.getMessage());
        }
    }


    @Override
    public Hotel getHotelById(int id) {
        String query = "SELECT * FROM hotels WHERE hotelId = ?";
        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                Hotel hotel = new Hotel();
                hotel.setHotelId(resultSet.getInt("hotelId"));
                hotel.setHotelName(resultSet.getString("hotelName"));
                hotel.setHotelLocation(resultSet.getString("hotelLocation"));
                hotel.setHotelRanking(resultSet.getFloat("hotelRanking"));
                hotel.setGymAvailable(resultSet.getBoolean("gymAvailable"));
                hotel.setPoolAvailable(resultSet.getBoolean("poolAvailable"));
                hotel.setSpaAvailable(resultSet.getBoolean("spaAvailable"));
                return hotel;
            }
        } catch (LowRankingException |SQLException e) {
            e.printStackTrace();
        }
        return null;
    }


    @Override
    public void deleteHotel(int id) {
        String query = "DELETE FROM hotels WHERE hotelId = ?";
        try (Connection connection = JDBCUtils.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, id);
            int row  = preparedStatement.executeUpdate();
            if(row>0){
                System.out.println("Deleted successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
 