package com.examly.springapp;


import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.examly.springapp.exception.LowRankingException;
import com.examly.springapp.model.Hotel;
import com.examly.springapp.service.HotelService;


@SpringBootApplication
public class HotelApp {

    public static void main(String[] args) {
        SpringApplication.run(HotelApp.class, args);
        HotelService hotelService = new HotelService();
        Scanner scanner = new Scanner(System.in);


        while (true) {
            System.out.println("1. Please Add details");
            System.out.println("2. Display All Hotels");
            System.out.println("3. Update Hotel by ID");
            System.out.println("4. Delete Hotel by ID");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();


            switch (choice) {
                case 1:
                    Hotel hotel = new Hotel();
                    System.out.print("Enter ID: ");
                    hotel.setHotelId(scanner.nextInt());
                    scanner.nextLine(); 
                    System.out.print("Enter Name: ");
                    hotel.setHotelName(scanner.nextLine());
                    System.out.print("Enter Location: ");
                    hotel.setHotelLocation(scanner.nextLine());
                    System.out.print("Enter Ranking: ");
                    try {
                        hotel.setHotelRanking(scanner.nextFloat());
                    } catch (LowRankingException e) {
                        System.out.println("Error: " + e.getMessage());
                        break;
                    }
                    System.out.print("Is Gym Available or not Available: ");
                    hotel.setGymAvailable(scanner.nextBoolean());
                    System.out.print("Is Pool Available or not Available: ");
                    hotel.setPoolAvailable(scanner.nextBoolean());
                    System.out.print("Is Spa Available or not Available ");
                    hotel.setSpaAvailable(scanner.nextBoolean());
                    hotelService.createHotel(hotel);
                    break;
                case 2:
                    hotelService.viewAllHotels();
                    break;
                case 3:
                    
                    System.out.print("Enter ID to update: ");
                    int updateId = scanner.nextInt();
                    Hotel updateHotel = hotelService.getHotelById(updateId);
                    if (updateHotel != null) {
                        scanner.nextLine();
                        System.out.print("Enter new Name: ");
                        updateHotel.setHotelName(scanner.nextLine());
                        System.out.print("Enter new Location: ");
                        updateHotel.setHotelLocation(scanner.nextLine());
                        System.out.print("Enter new Ranking: ");
                        try {
                            updateHotel.setHotelRanking(scanner.nextFloat());
                        } catch (LowRankingException e) {
                            System.out.println("Error: " + e.getMessage());
                            break;
                        }
                        System.out.print("Is Gym Available or not Available ");
                        updateHotel.setGymAvailable(scanner.nextBoolean());
                        System.out.print("Is Pool Available or not Available ");
                        updateHotel.setPoolAvailable(scanner.nextBoolean());
                        System.out.print("Is Spa Available or not Available ");
                        updateHotel.setSpaAvailable(scanner.nextBoolean());
                        hotelService.updateHotel(updateHotel);
                    } else {
                        System.out.println("Hotel not found!");
                    }
                    break;
                case 4:
                    System.out.print("Enter ID to delete: ");
                    int deleteId = scanner.nextInt();
                    hotelService.deleteHotel(deleteId);
                    break;
                case 5:
                    System.out.println("Exited");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Sorry Invalid choice!");
            }
        }
    }
    
    // Rest of the methods for sorting and displaying data
}
