package com.examly.springapp.model;


import com.examly.springapp.exception.LowRankingException;


public class Hotel {
    private int hotelId;
    private String hotelName;
    private String hotelLocation;
    private float hotelRanking;
    private boolean gymAvailable;
    private boolean poolAvailable;
    private boolean spaAvailable;

    public int getHotelId() {
        return hotelId;
    }
    public void setHotelId(int hotelId) {
        this.hotelId = hotelId;
    }
    public String getHotelName() {
        return hotelName;
    }
    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }
    public String getHotelLocation() {
        return hotelLocation;
    }
    public void setHotelLocation(String hotelLocation) {
        this.hotelLocation = hotelLocation;
    }
    public float getHotelRanking() {
        return hotelRanking;
    }
    public void setHotelRanking(float hotelRanking) throws LowRankingException {
        if (hotelRanking < 4.0f) {
            throw new LowRankingException("Hotel ranking too low: " + hotelRanking);
        }
        this.hotelRanking = hotelRanking;
    }
    public boolean isGymAvailable() {
        return gymAvailable;
    }
    public void setGymAvailable(boolean gymAvailable) {
        this.gymAvailable = gymAvailable;
    }
    public boolean isPoolAvailable() {
        return poolAvailable;
    }
    public void setPoolAvailable(boolean poolAvailable) {
        this.poolAvailable = poolAvailable;
    }
    public boolean isSpaAvailable() {
        return spaAvailable;
    }
    public void setSpaAvailable(boolean spaAvailable) {
        this.spaAvailable = spaAvailable;
    }
    @Override
    public String toString() {
        return "Hotel:  hotelId=" + hotelId + ", hotelName=" + hotelName + ", hotelLocation=" + hotelLocation
                + ", hotelRanking=" + hotelRanking + ", gymAvailable=" + gymAvailable + ", poolAvailable="
                + poolAvailable + ", spaAvailable=" + spaAvailable;
    }

    
    public Hotel(int hotelId,String hotelName, String hotelLocation,float hotelRanking, boolean gymAvailable, boolean poolAvailable, boolean spaAvailable){
        this.hotelId = hotelId;
        this.hotelName = hotelName;
        this.hotelLocation = hotelLocation;
        try{
            if(hotelRanking < 4.0f){
                throw new LowRankingException("Hotel ranking too low: "+hotelRanking);
            }
            this.hotelRanking = hotelRanking;
        }catch(LowRankingException lre){
            System.out.println(lre.getMessage());
        }
        this.gymAvailable = gymAvailable;
        this.poolAvailable = poolAvailable;
        this.spaAvailable = spaAvailable;
    }
    public Hotel() {
        
    }
}