package com.examly.springapp.exception;
public class LowRankingException extends Exception {
    public LowRankingException(String message) {
        super(message);
    }
}