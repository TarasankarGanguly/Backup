
function submitData(){
    document.getElementById('hotelForm').addEventListener("submit", (event) => event.preventDefault());
  
    let  hotelName = document.getElementById('hotelName').value;
    let  location = document.getElementById('location').value;
    let  rating = document.getElementById('rating').value;
    let isPool;
    let  pool = document.getElementById('pool');
    if(pool.checked) {isPool="Yes";}
    else {isPool="No";}
    
    let  gym = document.getElementById('gym');
    let isGym;
    if(gym.checked) {isGym="Yes";}
    else {isGym="No";}
  
    let  spa = document.getElementById('spa');
    let isSpa;
    if(spa.checked) {isSpa="Yes";}
    else {isSpa="No";}
    
    let hotelList = document.getElementById('hotelList');
    let tr = hotelList.insertRow(0);
  
    tr.innerHTML = `
      <tr>
        <td>${hotelName}</td>
        <td>${location}</td>
        <td>${rating}</td>
        <td>${isPool}</td>
        <td>${isGym}</td>
        <td>${isSpa}</td>
    </tr>
    `;
  
  }
  