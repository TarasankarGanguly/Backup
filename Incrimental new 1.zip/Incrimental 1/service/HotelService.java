package com.examly.springapp.service;
import com.examly.springapp.dao.HotelDAO;
import com.examly.springapp.dao.HotelDAOImpl;
import com.examly.springapp.model.Hotel;
public class HotelService {
    private HotelDAO hotelDAO = new HotelDAOImpl();
    
    public void addHoteldetailsInList(Hotel hotel) {
        hotelDAO.addHotelDetailsInList(hotel);
    }
    public void viewAllHotels() {
        hotelDAO.viewAllHotels();
    }
    public void createHotel(Hotel hotel) {
        hotelDAO.createHotel(hotel);
    }
    public void updateHotel(Hotel hotel) {
        hotelDAO.updateHotel(hotel);
    }
    public Hotel getHotelById(int id) {
        return hotelDAO.getHotelById(id);
    }
    public void deleteHotel(int id) {
        hotelDAO.deleteHotel(id);
    }
}
