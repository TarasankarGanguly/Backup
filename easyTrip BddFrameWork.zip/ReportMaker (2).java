package stepdefinition;

import com.aventstack.extentreports.ExtentReports;

import io.cucumber.java.AfterAll;
import io.cucumber.java.BeforeAll;
import utils.Reporter;

public class ReportMaker {
    public static ExtentReports reports;
    
    @BeforeAll
    public static void generate(){
        reports = Reporter.generateExtentReport("report");
    }

    @AfterAll
    public static void flushReports(){
        reports.flush();
    }


}
