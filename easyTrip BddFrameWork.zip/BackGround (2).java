package stepdefinition;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import utils.Base;

public class BackGround extends Base{

    @Before
    public void startBrowser(){
        openBrowser();
    }
    @After
    public void endBrowser(){
        driver.quit();
    }

}
