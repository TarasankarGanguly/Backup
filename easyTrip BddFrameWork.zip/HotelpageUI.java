package uistore;

import org.openqa.selenium.By;

public class HotelpageUI {
        public static By hotels = By.xpath("//span[text()='Hotels']");
        public static By Enter = By.xpath("//div[@class='htl_location shwbx']");
        public static By pune = By.xpath("//a[text()='Pune']");
        public static By rooms = By.xpath("//div[@class='hp_inputBox roomGuests']");
        public static By addrooms = By.xpath("//a[@id='addhotelRoom']");
        public static By done = By.xpath("//a[@id='exithotelroom']");
        public static By searchbtn = By.xpath("//input[@id='btnSearch']");
        public static By selectFilter = By.xpath("//div[text()='Select Filters']");

}
