package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.Flightpage;
import utils.Base;

public class DestinationStep extends Base {
    Flightpage flight = new Flightpage(driver);

    @When("I click on the from field")
    public void i_click_on_the_from_field() {
        flight.Fromfield();
    }

    @When("I input {string} from values")
    public void i_input_from_values(String string) {
        flight.ChennaiInput(string);
    }

    @When("click on Chennai in the suggestion box")
    public void click_on_chennai_in_the_suggestion_box() {
        flight.SuggestionFromInput();
    }

    @When("I click on New Delhi in the suggestion box")
    public void i_click_on_new_delhi_in_the_suggestion_box() {
        flight.SuggestionToInput();
    }

    @When("I click on departure and select fourteenth of the next month")
    public void i_click_on_departure_and_select_fourteenth_of_the_next_month() {
        flight.selectDepartureDate();
    }

    @When("I click on return and select fourteenth of the next month")
    public void i_click_on_return_and_select_fourteenth_of_the_next_month() throws InterruptedException {
        flight.SelectReturnDate();
    }

    @Then("I validate {string} and capture Screenshot")
    public void i_validate_and_capture_screenshot(String string) {
        flight.verifyCity(string);
    }

}
