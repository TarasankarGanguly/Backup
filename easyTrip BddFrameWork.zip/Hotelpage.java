package pages;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import stepdefinition.ReportMaker;
import uistore.FlightpageUI;
import uistore.HotelpageUI;
import utils.Screenshot;
import utils.WebDriverHelper;

public class Hotelpage {
    WebDriver driver;
    WebDriverHelper helper;
    ExtentTest test;

    public Hotelpage(WebDriver driver) {
        this.driver = driver;
        helper = new WebDriverHelper(driver);
        test = ReportMaker.reports.createTest("The report has been created successfully");
    }

    public void ClickHotels() {
        helper.waitForElementToBeVisible(HotelpageUI.hotels, 20);
        helper.clickOnElement(HotelpageUI.hotels);
    }

    public void ClickEnterLocation() {
        helper.waitForElementToBeVisible(HotelpageUI.Enter, 20);
        helper.clickOnElement(HotelpageUI.Enter);
    }

    public void EnterPune() {
        helper.waitForElementToBeVisible(HotelpageUI.pune, 20);
        helper.clickOnElement(HotelpageUI.pune);
    }

    public void ClickRooms() {
        helper.waitForElementToBeVisible(HotelpageUI.rooms, 20);
        helper.clickOnElement(HotelpageUI.rooms);
        helper.waitForElementToBeVisible(HotelpageUI.addrooms, 20);
        helper.clickOnElement(HotelpageUI.addrooms);
    }

    public void DoneRooms() {
        helper.waitForElementToBeVisible(HotelpageUI.done, 20);
        helper.clickOnElement(HotelpageUI.done);
    }

    public void ClickSearchButton() {
        helper.waitForElementToBeVisible(HotelpageUI.searchbtn, 20);
        helper.clickOnElement(HotelpageUI.searchbtn);
        Screenshot.captureScreenShot("Select Filters");
    }

    public void validateFilter(String details) {
        String filter = helper.getText(HotelpageUI.selectFilter);
        Assert.assertTrue(filter.contains(details));
    }
}
