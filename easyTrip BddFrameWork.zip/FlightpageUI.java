package uistore;

import org.openqa.selenium.By;

public class FlightpageUI {
    public static By from = By.xpath("//input[@id = 'FromSector_show']");
    public static By fromInput = By.xpath("//input[@id='a_FromSector_show']");
    public static By fromChennai = By.xpath("//span[@id='spnChennai']");
    public static By ToDelhi = By.xpath("//span[@id = 'spn12']");
    public static By ddate=By.xpath("//input[@id='ddate']");
    public static By fourteenth=By.xpath("//li[@id='snd_6_14/12/2024']");
    public static By rdate=By.xpath("//div[@id='divRtnCal']");
    public static By sixteenth=By.xpath("//li[@id='trd_4_16/01/2025']");
    public static By validCity =By.xpath("//li[text()='Multicity ']");
}
