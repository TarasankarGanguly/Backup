package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.Hotelpage;
import utils.Base;

public class HotelStep extends Base {
    Hotelpage hotel = new Hotelpage(driver);

    @When("I click on the hotels in the navigation bar")
    public void i_click_on_the_hotels_in_the_navigation_bar() {
        hotel.ClickHotels();
    }
    // @When("click on the close button in the pop up")
    // public void click_on_the_close_button_in_the_pop_up() {

    // }
    @When("click on the Enter the city name or location field")
    public void click_on_the_enter_the_city_name_or_location_field() {
        hotel.ClickEnterLocation();
    }

    @When("I click on Pune available in the search list")
    public void i_click_on_pune_available_in_the_search_list() {
        hotel.EnterPune();
    }

    @When("click on addrooms in therooms and guests field")
    public void click_on_addrooms_in_therooms_and_guests_field() {
        hotel.ClickRooms();
    }

    @When("click on the done button")
    public void click_on_the_done_button() {
        hotel.DoneRooms();
    }

    @When("click on the search button")
    public void click_on_the_search_button() {
        hotel.ClickSearchButton();
    }

    @Then("I validate {string}")
    public void i_validate(String string) {
        hotel.validateFilter(string);
    }
}
