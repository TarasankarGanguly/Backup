package pages;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import stepdefinition.ReportMaker;
import uistore.FlightpageUI;
import utils.Screenshot;
import utils.WebDriverHelper;

public class Flightpage {
    WebDriver driver;
    WebDriverHelper helper;
    ExtentTest test;
    public Flightpage(WebDriver driver){
        this.driver=driver;
        helper=new WebDriverHelper(driver);
        test=ReportMaker.reports.createTest("The Destination report has been created");
    }
    public void Fromfield(){
        helper.waitForElementToBeVisible(FlightpageUI.from, 20);
        helper.clickOnElement(FlightpageUI.from);
    }
    public void ChennaiInput(String dest){
        helper.sendKeys(FlightpageUI.fromInput,dest);
    }
    public void SuggestionFromInput(){
        helper.waitForElementToBeVisible(FlightpageUI.fromChennai, 20);
        helper.clickOnElement(FlightpageUI.fromChennai);
    }
    public void SuggestionToInput(){
        helper.waitForElementToBeVisible(FlightpageUI.ToDelhi, 20);
        helper.clickOnElement(FlightpageUI.ToDelhi);
    }
    public void selectDepartureDate(){
        helper.waitForElementToBeVisible(FlightpageUI.fourteenth, 20);
        helper.clickOnElement(FlightpageUI.fourteenth);
    }
    public void SelectReturnDate(){
        helper.waitForElementToBeVisible(FlightpageUI.rdate, 20);
        helper.clickOnElement(FlightpageUI.rdate);
        helper.waitForElementToBeVisible(FlightpageUI.sixteenth, 20);
        helper.clickOnElement(FlightpageUI.sixteenth);
        Screenshot.captureScreenShot("Multicity Present");
    }
    public void verifyCity(String expected){
        String city = helper.getText(FlightpageUI.validCity);
        Assert.assertTrue(city.contains(expected));
    }
}
